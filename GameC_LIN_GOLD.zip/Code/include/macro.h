#ifndef __MACRO__
#define __MACRO__

#define GAME_WIDTH 1280
#define GAME_HEIGHT 960

#define GAME_WIDTH_SLOT 40
#define GAME_HEIGHT_SLOT 30

#endif